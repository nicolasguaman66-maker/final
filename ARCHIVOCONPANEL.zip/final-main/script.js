
const CONFIG = {
  branches: {
    cusubamba:    { name: "Local Santa Rosa de Cusubamba", whatsapp: "593998403920", display: "+593 99 840 3920" },
    guayllabamba: { name: "Local Guayllabamba",            whatsapp: "593998707995", display: "+593 99 870 7995" },
  },
  social: {
    facebook:  "https://www.facebook.com/",
    instagram: "https://www.instagram.com/",
  },
};


const PRODUCTS = {
  /* Instituciones educativas.
     Las rutas de las fotos YA ESTÁN puestas. Solo copia tus fotos en la carpeta img/uniformes/
     con estos nombres exactos (en minúsculas y .jpg):
       institucion1-deportivo.jpg   institucion1-lunes.jpg   institucion1-diario.jpg
       institucion2-deportivo.jpg   ... y así hasta institucion6
     Si una foto todavía no está en la carpeta, el recuadro muestra "Foto próximamente".
     logo: es el escudo de la institución que se ve arriba en su tarjeta (está en img/logos/).
     Aquí también puedes cambiar el nombre de cada institución. */
  educativos: [
    { name: "Institución Educativa Guayllabamba", logo: "img/logos/institucion1-logo.png", uniformes: { deportivo: "img/uniformes/institucion1-deportivo.jpg", lunes: "img/uniformes/institucion1-lunes.jpg", diario: "img/uniformes/institucion1-diario.jpg" } },
    { name: "Institución Educativa SFQ", logo: "img/logos/institucion2-logo.jpg", uniformes: { deportivo: "img/uniformes/institucion2-deportivo.jpg", lunes: "img/uniformes/institucion2-lunes.jpg", diario: "img/uniformes/institucion2-diario.jpg" } },
    { name: "Institución Educativa Ingapirca", logo: "img/logos/institucion3-logo.jpg", uniformes: { deportivo: "img/uniformes/institucion3-deportivo.jpg", lunes: "img/uniformes/institucion3-lunes.jpg", diario: "img/uniformes/institucion3-diario.jpg" } },
    { name: "Institución Educativa Ascázubi", logo: "img/logos/institucion4-logo.jpg", uniformes: { deportivo: "img/uniformes/institucion4-deportivo.jpg", lunes: "img/uniformes/institucion4-lunes.jpg", diario: "img/uniformes/institucion4-diario.jpg" } },
    { name: "Institución Educativa Luis Pasteur", logo: "", uniformes: { deportivo: "img/uniformes/institucion5-deportivo.jpg", lunes: "img/uniformes/institucion5-lunes.jpg", diario: "img/uniformes/institucion5-diario.jpg" } },
    { name: "Institución Educativa Junín", logo: "", uniformes: { deportivo: "img/uniformes/institucion6-deportivo.jpg", lunes: "img/uniformes/institucion6-lunes.jpg", diario: "img/uniformes/institucion6-diario.jpg" } },
  ].map((p, i) => ({
    ...p,
    desc: "Uniformes de diario y deportivos confeccionados con telas resistentes y acabados de primera calidad.",
    image: "", icon: "cap", chip: "Educativo",
    colors: [["#1c1917"], ["#0a0a0a"], ["#7c2d12"]][i % 3],
  })),
  /* Uniformes deportivos.
     IMPORTANTE: en la página publicada, las fotos de "Ver productos" de Deportivos y Otros
     (y las Promociones) se manejan desde el PANEL (tupagina.com/admin) y se guardan en
     data/contenido.json. Las listas "fotos" de aquí solo se usan si ese archivo no se puede leer
     (por ejemplo, al abrir la página directo desde la computadora). */
  deportivos: [
    { id: "futbol", name: "Uniformes de fútbol",   desc: "Juegos completos para equipos: camiseta, short y medias con tu escudo.", icon: "trophy",
      fotos: [
        "img/deportivos/futbol/futbol1.jpg",
        "img/deportivos/futbol/futbol2.jpg",
        "img/deportivos/futbol/futbol3.jpg",
        "img/deportivos/futbol/futbol4.jpg",
        "img/deportivos/futbol/futbol5.jpg",
        "img/deportivos/futbol/futbol6.jpg",
      ] },
    { id: "camisetas", name: "Camisetas deportivas",   desc: "Camisetas transpirables y ligeras con sublimación personalizada.", icon: "shirt",
      fotos: [
        "img/deportivos/camisetas/camiseta1.jpg",
        "img/deportivos/camisetas/camiseta2.jpg",
        "img/deportivos/camisetas/camiseta3.jpg",
        "img/deportivos/camisetas/camiseta4.jpg",
        "img/deportivos/camisetas/camiseta5.jpg",
        "img/deportivos/camisetas/camiseta6.jpg",
      ] },
    { id: "chompas-promocion", name: "Chompas de promoción",  desc: "Chompas personalizadas para promociones y graduados, con nombre, curso y año.", icon: "shirt", fotos: [] },
    { id: "chompas-chaquetas", name: "Chompas y chaquetas",    desc: "Chaquetas deportivas para delegaciones, clubes y organizaciones.", icon: "shirt", fotos: [] },
  ].map((p, i) => ({ ...p, image: "", chip: "Deportivo", colors: [["#7c2d12"], ["#1c1917"], ["#0a0a0a"]][i % 3] })),
  /* Otros: igual que en deportivos, las fotos se manejan desde el panel. */
  otros: [
    { id: "mandiles", name: "Mandiles",                desc: "Mandiles escolares y de trabajo confeccionados en distintos colores y tallas.", icon: "shirt", fotos: [] },
    { id: "estandartes", name: "Estandartes deportivos",  desc: "Estandartes para desfiles, inauguraciones y eventos deportivos, con el escudo de tu equipo o institución.", icon: "trophy", fotos: [] },
    { id: "bandas-madrinas", name: "Bandas de madrinas",      desc: "Bandas personalizadas para madrinas de equipos, cursos e instituciones.", icon: "award", fotos: [] },
    { id: "gorras-accesorios", name: "Gorras y accesorios",     desc: "Gorras y complementos personalizados con tu logo o diseño.", icon: "bag", fotos: [] },
    { id: "balones", name: "Balones",                 desc: "Balones para tu equipo, institución o evento deportivo.", icon: "trophy", fotos: [] },
  ].map((p, i) => ({ ...p, image: "", chip: "Otros", colors: [["#0a0a0a"], ["#9a3412"]][i % 2] })),
};


(() => {
  "use strict";

  const $  = (sel, ctx = document) => ctx.querySelector(sel);
  const $$ = (sel, ctx = document) => [...ctx.querySelectorAll(sel)];
  const reduceMotion = matchMedia("(prefers-reduced-motion: reduce)").matches;


  document.documentElement.classList.remove("no-js");


  const esc = (s) => String(s).replace(/[&<>"']/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]));


  function renderCards() {
    Object.entries(PRODUCTS).forEach(([key, items]) => {
      const grid = $(`#grid-${key}`);
      if (!grid) return;
      grid.innerHTML = items.map((p, i) => {
        const [c1] = p.colors || ["#1c1917"];
        const media = p.logo
          ? `<img class="card__logo" src="${esc(p.logo)}" alt="Escudo de ${esc(p.name)}" loading="lazy" />`
          : p.image
          ? `<img src="${esc(p.image)}" alt="${esc(p.name)}" loading="lazy" />`
          : `<svg class="icon" aria-hidden="true"><use href="#i-${esc(p.icon)}"/></svg>`;
        return `
          <article class="card reveal" style="--d:${(i % 3) * 0.08}s">
            <div class="card__media${p.logo ? " card__media--logo" : ""}" style="--c1:${c1}">
              ${media}<span class="card__chip">${esc(p.chip)}</span>
            </div>
            <div class="card__body">
              <h4>${esc(p.name)}</h4>
              <p>${esc(p.desc)}</p>
              ${Array.isArray(p.fotos) ? `<button class="btn btn--outline" data-gallery="${esc(key)}:${i}">Ver productos <svg class="icon"><use href="#i-shirt"/></svg></button>` : ""}
              ${p.uniformes ? `<button class="btn btn--outline" data-uniforms="${esc(key)}:${i}">Ver uniformes <svg class="icon"><use href="#i-shirt"/></svg></button>` : ""}
              <button class="btn btn--dark" data-quote="${esc(p.name)}">Solicitar Cotización <svg class="icon"><use href="#i-arrow"/></svg></button>
            </div>
          </article>`;
      }).join("");
    });
  }


  function waLink(branchKey, text = "Hola ANK, quisiera más información sobre sus uniformes.") {
    const b = CONFIG.branches[branchKey];
    return `https://wa.me/${b.whatsapp}?text=${encodeURIComponent(text)}`;
  }
  function applyConfig() {
    $$("[data-wa]").forEach((a) => { a.href = waLink(a.dataset.wa); });
    $$("[data-phone]").forEach((el) => { el.textContent = CONFIG.branches[el.dataset.phone].display; });
    $$("[data-social]").forEach((a) => { a.href = CONFIG.social[a.dataset.social] || "#"; });
    const y = $("#year"); if (y) y.textContent = new Date().getFullYear();
  }


  function initNavbar() {
    const navbar = $("#navbar"), nav = $("#nav"), burger = $("#burger");
    const onScroll = () => navbar.classList.toggle("is-scrolled", window.scrollY > 30);
    onScroll();
    window.addEventListener("scroll", onScroll, { passive: true });

    const setMenu = (open) => {
      nav.classList.toggle("is-open", open);
      burger.setAttribute("aria-expanded", open);
      burger.innerHTML = `<svg class="icon"><use href="#i-${open ? "x" : "menu"}"/></svg>`;
      document.body.classList.toggle("no-scroll", open);
    };
    burger.addEventListener("click", () => setMenu(!nav.classList.contains("is-open")));
    $$("a, button", nav).forEach((el) => el.addEventListener("click", () => setMenu(false)));
    document.addEventListener("keydown", (e) => { if (e.key === "Escape") setMenu(false); });


    const map = { inicio: ["inicio", "historia", "productos"], categorias: ["categorias"], contacto: ["contacto"] };
    const links = $$(".nav__link");
    const spy = new IntersectionObserver((entries) => {
      entries.forEach((en) => {
        if (!en.isIntersecting) return;
        const key = Object.keys(map).find((k) => map[k].includes(en.target.id));
        links.forEach((l) => l.classList.toggle("is-active", l.dataset.section === key));
      });
    }, { rootMargin: "-45% 0px -50% 0px" });
    $$("main section[id]").forEach((s) => spy.observe(s));
  }


  function initFeatureCards() {
    $$("[data-goto]").forEach((card) => {
      const go = () => document.querySelector(card.dataset.goto)?.scrollIntoView({ behavior: reduceMotion ? "auto" : "smooth" });
      card.addEventListener("click", (e) => { e.preventDefault(); go(); });
      card.addEventListener("keydown", (e) => { if (e.key === "Enter" || e.key === " ") { e.preventDefault(); go(); } });
    });
  }


  function initReveal() {
    const items = $$(".reveal");
    if (!("IntersectionObserver" in window) || reduceMotion) { items.forEach((i) => i.classList.add("is-visible")); return; }
    const io = new IntersectionObserver((entries) => {
      entries.forEach((en) => { if (en.isIntersecting) { en.target.classList.add("is-visible"); io.unobserve(en.target); } });
    }, { threshold: 0.12, rootMargin: "0px 0px -40px 0px" });
    items.forEach((i) => io.observe(i));
  }

  function initCounters() {
    const fmt = (n, sep) => String(n).replace(/\B(?=(\d{3})+(?!\d))/g, sep || "");
    const run = (el) => {
      const target = +el.dataset.count, prefix = el.dataset.prefix || "", sep = el.dataset.sep || "";
      if (reduceMotion) { el.textContent = prefix + fmt(target, sep); return; }
      const dur = 1600, t0 = performance.now();
      const tick = (t) => {
        const p = Math.min((t - t0) / dur, 1), eased = 1 - Math.pow(1 - p, 4);
        el.textContent = prefix + fmt(Math.round(target * eased), sep);
        if (p < 1) requestAnimationFrame(tick);
      };
      requestAnimationFrame(tick);
    };
    const io = new IntersectionObserver((entries) => {
      entries.forEach((en) => { if (en.isIntersecting) { run(en.target); io.unobserve(en.target); } });
    }, { threshold: 0.6 });
    $$("[data-count]").forEach((el) => io.observe(el));
  }


  function initParallax() {
    if (reduceMotion) return;
    const els = $$("[data-parallax]");
    let ticking = false;
    const update = () => {
      els.forEach((el) => {
        const r = el.getBoundingClientRect();
        if (r.bottom < 0 || r.top > innerHeight) return;
        const offset = (r.top + r.height / 2 - innerHeight / 2) * parseFloat(el.dataset.parallax);
        el.style.transform = `translateY(${offset.toFixed(1)}px)`;
      });
      ticking = false;
    };
    window.addEventListener("scroll", () => { if (!ticking) { ticking = true; requestAnimationFrame(update); } }, { passive: true });
    update();
  }

  /* ----- Modales (accesibles: Esc, foco, clic fuera) ----- */
  let lastFocus = null;
  function openModal(modal) {
    lastFocus = document.activeElement;
    modal.classList.add("is-open");
    modal.setAttribute("aria-hidden", "false");
    document.body.classList.add("no-scroll");
    setTimeout(() => ($(".branch-option, button.btn", modal) || $(".modal__close", modal))?.focus(), 80);
  }
  function closeModal(modal) {
    modal.classList.remove("is-open");
    modal.setAttribute("aria-hidden", "true");
    document.body.classList.remove("no-scroll");
    lastFocus?.focus?.();
  }
  function initModals() {
    $$(".modal").forEach((m) => {
      $$("[data-close]", m).forEach((b) => b.addEventListener("click", () => closeModal(m)));
    });
    document.addEventListener("keydown", (e) => {
      if (e.key === "Escape") $$(".modal.is-open").forEach(closeModal);
      // Mantener el foco dentro del modal abierto
      if (e.key === "Tab") {
        const m = $(".modal.is-open"); if (!m) return;
        const f = $$("a[href],button:not([disabled]),input,select,textarea", m).filter((x) => x.offsetParent !== null);
        if (!f.length) return;
        const first = f[0], last = f[f.length - 1];
        if (e.shiftKey && document.activeElement === first) { e.preventDefault(); last.focus(); }
        else if (!e.shiftKey && document.activeElement === last) { e.preventDefault(); first.focus(); }
      }
    });
    // Textos legales: muestra en el recuadro solo el documento del enlace pulsado
    $$("[data-legal]").forEach((a) => a.addEventListener("click", (e) => {
      e.preventDefault();
      const modal = $("#legalModal");
      $("#legalTitle").textContent = a.dataset.legal;
      $$("[data-legal-doc]", modal).forEach((doc) => { doc.hidden = doc.dataset.legalDoc !== a.dataset.legal; });
      openModal(modal);
      // El texto siempre empieza desde arriba
      const dialog = $(".modal__dialog", modal);
      dialog.scrollTop = 0;
      setTimeout(() => { dialog.scrollTop = 0; }, 120);
    }));
  }

  /* ----- Cotización: el usuario elige el local y se abre el WhatsApp de ese local ----- */
  function initQuote() {
    const modal = $("#quoteModal"), lead = $("#quoteLead");
    const options = $$("[data-local]", modal);
    const defaultLead = lead.textContent;

    // Cualquier botón [data-quote] abre el modal; si trae un producto, se incluye en el mensaje
    document.addEventListener("click", (e) => {
      const btn = e.target.closest("[data-quote]");
      if (!btn) return;
      e.preventDefault();
      const product = btn.dataset.quote;
      const text = product
        ? `Hola ANK, quisiera solicitar una cotización de: ${product}.`
        : "Hola ANK, quisiera solicitar una cotización.";
      lead.textContent = product ? `Cotización de: ${product}. Elige el local y te atenderemos por WhatsApp.` : defaultLead;
      // Son enlaces reales (<a target="_blank">): el navegador no los bloquea como ventanas emergentes
      options.forEach((o) => { o.href = waLink(o.dataset.local, text); });
      openModal(modal);
    });

    options.forEach((o) => o.addEventListener("click", () => setTimeout(() => closeModal(modal), 150)));
  }

  /* ----- Uniformes de cada institución: recuadro con fotos (deportivo, lunes, diario) ----- */
  function initUniforms() {
    const modal = $("#uniformsModal");
    if (!modal) return;
    const title = $("#uniformsTitle"), tabs = $$("[data-uniform-tab]", modal);
    const img = $("#uniformsImg"), empty = $("#uniformsEmpty");
    let current = null;

    function show(type) {
      tabs.forEach((t) => {
        const on = t.dataset.uniformTab === type;
        t.classList.toggle("is-active", on);
        t.setAttribute("aria-selected", on ? "true" : "false");
      });
      const src = current?.uniformes?.[type] || "";
      const label = $(`[data-uniform-tab="${type}"]`, modal).textContent;
      if (src) {
        img.src = src; img.alt = `${label} - ${current.name}`;
        img.hidden = false; empty.hidden = true;
      } else {
        img.removeAttribute("src"); img.hidden = true; empty.hidden = false;
      }
    }

    document.addEventListener("click", (e) => {
      const btn = e.target.closest("[data-uniforms]");
      if (!btn) return;
      e.preventDefault();
      const [key, idx] = btn.dataset.uniforms.split(":");
      current = PRODUCTS[key]?.[Number(idx)];
      if (!current) return;
      title.textContent = current.name;
      show("deportivo");
      openModal(modal);
    });

    tabs.forEach((t) => t.addEventListener("click", () => show(t.dataset.uniformTab)));
    // Si la foto todavía no está en la carpeta, se muestra "Foto próximamente"
    img.addEventListener("error", () => { img.hidden = true; empty.hidden = false; });
  }

  /* ----- Álbum de fotos de cada apartado (uniformes deportivos) ----- */
  function initGallery() {
    const modal = $("#galleryModal");
    if (!modal) return;
    const title = $("#galleryTitle"), img = $("#galleryImg"), empty = $("#galleryEmpty");
    const counter = $("#galleryCount"), thumbs = $("#galleryThumbs");
    const prev = $("#galleryPrev"), next = $("#galleryNext"), stage = $(".gallery__stage", modal);
    let fotos = [], idx = 0, name = "";

    function show(n) {
      if (!fotos.length) return;
      idx = (n + fotos.length) % fotos.length;
      img.src = fotos[idx];
      img.alt = `${name} - foto ${idx + 1} de ${fotos.length}`;
      counter.textContent = `${idx + 1} / ${fotos.length}`;
      $$("button", thumbs).forEach((b, i) => {
        b.classList.toggle("is-active", i === idx);
        if (i === idx) b.scrollIntoView({ block: "nearest", inline: "center" });
      });
    }

    document.addEventListener("click", (e) => {
      const btn = e.target.closest("[data-gallery]");
      if (!btn) return;
      e.preventDefault();
      const [key, i] = btn.dataset.gallery.split(":");
      const p = PRODUCTS[key]?.[Number(i)];
      if (!p) return;
      name = p.name; fotos = (p.fotos || []).filter(Boolean);
      title.textContent = name;
      const has = fotos.length > 0, many = fotos.length > 1;
      img.hidden = !has; empty.hidden = has;
      prev.hidden = next.hidden = counter.hidden = thumbs.hidden = !many;
      if (!has) img.removeAttribute("src");
      thumbs.innerHTML = fotos.map((f, n) =>
        `<button type="button" aria-label="Ver foto ${n + 1}"><img src="${esc(f)}" alt="" loading="lazy" /></button>`).join("");
      $$("button", thumbs).forEach((b, n) => b.addEventListener("click", () => show(n)));
      openModal(modal);
      show(0);
    });

    prev.addEventListener("click", () => show(idx - 1));
    next.addEventListener("click", () => show(idx + 1));
    document.addEventListener("keydown", (e) => {
      if (!modal.classList.contains("is-open") || fotos.length < 2) return;
      if (e.key === "ArrowLeft") show(idx - 1);
      if (e.key === "ArrowRight") show(idx + 1);
    });
    // Deslizar con el dedo en celular
    let x0 = null;
    stage.addEventListener("touchstart", (e) => { x0 = e.touches[0].clientX; }, { passive: true });
    stage.addEventListener("touchend", (e) => {
      if (x0 === null || fotos.length < 2) return;
      const dx = e.changedTouches[0].clientX - x0; x0 = null;
      if (Math.abs(dx) > 40) show(idx + (dx < 0 ? 1 : -1));
    });
  }

  /* ----- Contenido editable desde el panel (fotos de Deportivos/Otros y Promociones) ----- */
  const safePath = (p) => typeof p === "string" && /^(uploads|img)\/[\w\-./]+$/.test(p) && !p.includes("..");
  const todayStr = () => {
    const d = new Date();
    return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, "0")}-${String(d.getDate()).padStart(2, "0")}`;
  };
  const fmtDate = (s) => { const [y, m, d] = String(s).split("-"); return d && m && y ? `${d}/${m}/${y}` : ""; };
  const fmtMoney = (v) => {
    const n = Number(String(v).replace(",", "."));
    return Number.isFinite(n) && String(v).trim() !== "" ? `$${n.toFixed(2)}` : "";
  };

  function renderPromos(list) {
    const box = $("#promociones"), grid = $("#grid-promociones");
    if (!box || !grid) return;
    const hoy = todayStr();
    const activas = (Array.isArray(list) ? list : []).filter((p) =>
      p && p.activo && p.titulo && p.desde && p.hasta && p.desde <= hoy && hoy <= p.hasta);
    if (!activas.length) { box.hidden = true; grid.innerHTML = ""; return; }
    box.hidden = false;
    grid.innerHTML = activas.map((p) => {
      const media = safePath(p.foto)
        ? `<img src="${esc(p.foto)}" alt="${esc(p.titulo)}" loading="lazy" />`
        : `<svg class="icon" aria-hidden="true"><use href="#i-award"/></svg>`;
      const antes = fmtMoney(p.precio_antes), ahora = fmtMoney(p.precio_ahora);
      const precio = antes && ahora
        ? `<p class="promo__price"><span class="promo__old">Antes ${esc(antes)}</span> <span class="promo__new">Ahora ${esc(ahora)}</span></p>`
        : ahora ? `<p class="promo__price"><span class="promo__new">${esc(ahora)}</span></p>` : "";
      const beneficio = p.beneficio ? `<p class="promo__benefit">${esc(p.beneficio)}</p>` : "";
      const cond = p.condiciones ? `<details class="promo__cond"><summary>Ver condiciones</summary><p>${esc(p.condiciones)}</p></details>` : "";
      return `
        <article class="card promo-card">
          <div class="card__media card__media--promo">${media}<span class="card__chip">Promoción</span></div>
          <div class="card__body">
            <h4>${esc(p.titulo)}</h4>
            ${p.descripcion ? `<p>${esc(p.descripcion)}</p>` : ""}
            ${beneficio}${precio}
            <p class="promo__dates">Válido del ${esc(fmtDate(p.desde))} al ${esc(fmtDate(p.hasta))}</p>
            ${cond}
            <button class="btn btn--dark" data-quote="Promoción: ${esc(p.titulo)}">Lo quiero <svg class="icon"><use href="#i-arrow"/></svg></button>
          </div>
        </article>`;
    }).join("");
  }

  async function loadContent() {
    try {
      const r = await fetch(`data/contenido.json?v=${Date.now()}`, { cache: "no-store" });
      if (!r.ok) throw new Error("sin contenido");
      const data = await r.json();
      ["deportivos", "otros"].forEach((key) => {
        (data?.secciones?.[key] || []).forEach((s) => {
          const item = PRODUCTS[key]?.find((x) => x.id === s.id);
          if (item && Array.isArray(s.fotos)) item.fotos = s.fotos.filter(safePath);
        });
      });
      renderPromos(data.promociones);
    } catch (err) {
      renderPromos([]); // sin servidor (archivo abierto en la PC): se usan las fotos del código y no hay promociones
    }
  }

  /* ----- Inicio ----- */
  document.addEventListener("DOMContentLoaded", () => {
    renderCards();
    applyConfig();
    initNavbar();
    initFeatureCards();
    initModals();
    initQuote();
    initUniforms();
    initGallery();
    loadContent();
    initReveal();      // después de renderCards para incluir las tarjetas
    initCounters();
    initParallax();
  });
})();
