# ANK Sports — Sitio web

Sitio de ANK: catálogo de uniformes deportivos, educativos y otros productos, con cotización por WhatsApp.
Se publica en **Hostinger** (necesita PHP para el panel de administración).

## Carpetas y archivos
- `index.html`, `style.css`, `script.js` — la página.
- `img/` — imágenes fijas de la página (logos, escudos, uniformes de instituciones).
- `admin/` — **panel de administración** (tupagina.com/admin). No modificar.
  - `admin/config.php` — clave inicial del primer ingreso.
  - `admin/privado/` — contraseña cifrada del panel (protegida).
- `data/contenido.json` — lo que el panel guarda: fotos de Deportivos/Otros y Promociones.
- `uploads/` — fotos subidas desde el panel.

## Qué se cambia desde el panel (sin código)
- Fotos de "Ver productos" en **Uniformes deportivos** y **Otros**: subir, ordenar, eliminar.
- **Promociones**: crear, editar, ocultar, eliminar (con fechas de vigencia).

## Qué sigue en el código
- Teléfonos y redes: `CONFIG` en `script.js`.
- Nombres/descripciones de los recuadros e instituciones educativas: `PRODUCTS` en `script.js`.
- Textos legales: `index.html` (sección "Información Legal").

## Importante al actualizar la página en Hostinger
Si subes una versión nueva del sitio, **no reemplaces** `data/contenido.json`, la carpeta `uploads/`
ni `admin/privado/`: ahí están las fotos, promociones y la contraseña que cargaron los dueños.
